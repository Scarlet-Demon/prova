import { Schema, model } from 'mongoose'

const vehiclesSchema = new Schema({
    plate: {
        type: String,
        required: true
    },
    model: {
        type: String,
        required: true
    },
    year: {
        type: Number,
        required: true
    },
    owner: {
        type: Number,
        required: true
    },
    Maintenance: {
        type: Schema.Types.ObjectId,
        //ref: Maintenance,
        required: true
    },
})

export default model('Vehicle', vehiclesSchema)