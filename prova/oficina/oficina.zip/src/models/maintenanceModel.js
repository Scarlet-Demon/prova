import { Schema, model } from 'mongoose'

const maintenanceSchema = new Schema({
    Workshop: {
        type: Schema.Types.ObjectId,
        //ref: Workshops,
        required: true
    },
    Vehicle: {
        type: Schema.Types.ObjectId,
        //ref: Vehicles,
        required: true
    },
    services: {
        type: [{String, Number}],
        required: true
    },
    date: {
        type: Date,
        required: true
    },
    totalCost: {
        type: Number,
        required: true
    },
})

export default model('Maintenance', maintenanceSchema)